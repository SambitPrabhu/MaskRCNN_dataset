# Segmentation > augmented_segmentation
https://universe.roboflow.com/solar-inspection/segmentation-4sqbe

Provided by a Roboflow user
License: CC BY 4.0

